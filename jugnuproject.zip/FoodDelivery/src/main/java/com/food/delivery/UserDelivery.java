package com.food.delivery;

import java.util.List;

import com.food.daoimp1.MenuDAOImp1;
import com.food.model.Menu;

//public class UserDelivery {
//
//	public static void main(String[] args) {
//		//UserDAOImp1 u=new UserDAOImp1();
//		//User user=new User(2,"juggu","jug@123","junnu@gmail.com","siddiah gutta,dharmavaram","Customer");
//		//u.addUser(user);;
//		MenuDAOImp1 r=new MenuDAOImp1();
////	//	Restaurant restaurant= new Restaurant(1,"romantic","chinesesnoodles",2,"siddiahgutta",2,4.500,true,"image");
////		//r.addRestaurant(restaurant);
////		List<Restaurant> restauran=r.getAllRestaurants();
////		for(Restaurant res:restauran) {
////			System.out.println(res.getName());
////			
////		}
//		//r.deleteRestaurant(74);
////		MenuDAOImp1 m=new MenuDAOImp1();
//////		Menu menu=new Menu(1,1,"springnoodles","good",220.0,true);
//////		m.addMenu(menu);
//		List<Menu> menu=r.getAllMenusByRestaurant(102);
//		for(Menu res1:menu) {
//			System.out.println(res1);		
//			}
//
//	}
//
//}
