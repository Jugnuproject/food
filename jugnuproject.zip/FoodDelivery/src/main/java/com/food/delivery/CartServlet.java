package com.food.delivery;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.food.dao.MenuDAO;
import com.food.daoimp1.MenuDAOImp1;
import com.food.model.Cart;
import com.food.model.CartItem;
import com.food.model.Menu;

@WebServlet("/cart")
public class CartServlet extends HttpServlet {
	protected void doPost(HttpServletRequest request,HttpServletResponse resp) throws ServletException,IOException {
		HttpSession session=request.getSession();
		Cart cart=(Cart) session.getAttribute("cart");
		if(cart==null) {
			cart=new Cart();
			//session.setAttribute("cart",cart);
		}
		String action=request.getParameter("action");
		if(action.equals("add")) {
			addItemToCart(request,cart);
		}
		else if(action.equals("update")){
			updateCartItem(request,cart);
			
		}
		else if(action.equals("remove")) {
			removeItemFromCart(request,cart);
		}
		session.setAttribute("cart", cart);
		resp.sendRedirect("cart.jsp");
		
	}
//	protected void doGet(HttpServletRequest request,HttpServletResponse resp) throws ServletException,IOException{
//		request.getRequestDispatcher("cart.jsp").forward(request, resp);
//	}
	private void addItemToCart(HttpServletRequest request,Cart cart) {
		int itemId=Integer.parseInt(request.getParameter("itemId"));
		//System.out.println(itemId);
		int Quantity=Integer.parseInt(request.getParameter("quantity"));
		//System.out.println(quantity);
		MenuDAO menuDAO=new MenuDAOImp1();
		Menu menuItem=menuDAO.getMenu(itemId);
		HttpSession session=request.getSession();
		session.setAttribute("restaurantid", menuItem.getRestaurantid());
		if(menuItem!=null) {
			CartItem item=new CartItem(
					menuItem.getMenuid(),
					menuItem.getRestaurantid(),
					menuItem.getItemname(),
					Quantity,
					menuItem.getPrice()
			);
			//System.out.println(item);
			cart.addItem(item);
			//System.out.println(item);
			//System.out.println(item.getQuantity());
			//System.out.println(Quantity);
					
		}
	}
	private void updateCartItem(HttpServletRequest request,Cart cart) {
		int itemId=Integer.parseInt(request.getParameter("itemId"));
		//System.out.println(itemId);
		int quantity=Integer.parseInt(request.getParameter("quantity"));
		//System.out.println(quantity);
		cart.updateItem(itemId, quantity);
		
		
	}
	private void removeItemFromCart(HttpServletRequest request,Cart cart) {
		int itemId=Integer.parseInt(request.getParameter("itemId"));
		cart.removeItem(itemId);
		
	}

}
