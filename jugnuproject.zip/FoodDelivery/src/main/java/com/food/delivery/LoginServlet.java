package com.food.delivery;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.food.dao.UserDAO;
import com.food.daoimp1.UserDAOImp1;
import com.food.model.User;
@WebServlet("/login1")
public class LoginServlet extends HttpServlet {
	private UserDAO userDAO;
	@Override
	public void init() {
		userDAO=new UserDAOImp1();
	}
	protected void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException{
		String username=request.getParameter("username");
		//System.out.println(username);
		String password=request.getParameter("password");
		//System.out.println(password);
		User user=userDAO.getUserByUsername(username);
		//System.out.println(user);
		if(user!=null && user.getPassword().equals(password)) {
			HttpSession session=request.getSession();
			session.setAttribute("loggedInUser", user);
			response.sendRedirect("home");
			
		}
		else {
			request.setAttribute("error message", "invalid username or password");
			request.getRequestDispatcher("login.jsp").forward(request, response);
		}
	
	}
		
}
		
