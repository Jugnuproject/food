package com.food.delivery;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.food.daoimp1.UserDAOImp1;
import com.food.model.User;
@WebServlet("/signup")

public class Signup extends HttpServlet{
		
	protected void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException{
		String username=request.getParameter("username");
		//System.out.println(username);
		String password=request.getParameter("password");
		//System.out.println(password);
		String Email=request.getParameter("email");
		//System.out.println(Email);
		String address=request.getParameter("address");
		String role=request.getParameter("role");
		User user=new User();
		user.setUsername(username);
		user.setPassword(password);
		user.setEmail(Email);
		user.setAddress(address);
		user.setRole(role);
		UserDAOImp1 userimp=new UserDAOImp1();
		userimp.addUser(user);
		PrintWriter out=response.getWriter();
		out.print("<h1 style='color:red'>your signup is successfull</h1>");
		
		
		
		
	

	}

}
