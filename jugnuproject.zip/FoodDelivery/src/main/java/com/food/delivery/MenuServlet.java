package com.food.delivery;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.food.dao.MenuDAO;
import com.food.daoimp1.MenuDAOImp1;
import com.food.model.Menu;

@WebServlet("/menu")
public class MenuServlet extends HttpServlet {
	private MenuDAO menuDAO;
	public void init() {
		menuDAO=new MenuDAOImp1();
	}
	protected void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException {
		String restaurantid=request.getParameter("restaurantid");
		if(restaurantid!=null) {
			try {
				List<Menu> menuList=menuDAO.getAllMenusByRestaurant(Integer.parseInt(restaurantid));
				request.setAttribute("menuList",menuList);
//				for(Menu menu:menuList) {
//					System.out.println(menu);
//				}
//				
			}
			catch(NumberFormatException e) {
				
			}
		}
		RequestDispatcher dispatcher=request.getRequestDispatcher("menu.jsp");
		dispatcher.forward(request,response);		
	}
}


