package com.food.delivery;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.food.dao.OrderDAO;
import com.food.daoimp1.OrderDAOImp1;
import com.food.model.Cart;
import com.food.model.CartItem;
import com.food.model.Order;
import com.food.model.User;
@WebServlet("/checkout")
public class CheckoutServlet extends  HttpServlet {
	private OrderDAO orderDAO;
	public void init() {
		orderDAO=new OrderDAOImp1();
	}
	protected void doPost(HttpServletRequest request,HttpServletResponse resp) throws ServletException,IOException {
		HttpSession session=request.getSession();
		Cart cart=(Cart) session.getAttribute("cart");
		User user=(User)session.getAttribute("loggedInUser");
		//System.out.println(user);
		if(cart!=null && user!=null && !cart.getItems().isEmpty()) {
			//extract checkout form data
			String paymentMethod=request.getParameter("paymentMethod");
			//create and populate the order object
			Order order=new Order();
			order.setUserid(user.getUserId());
			//System.out.println(order);
			//System.out.println(session.getAttribute("restaurantid"));
			order.setRestaurantid((int)session.getAttribute("restaurantid"));
			order.setOrderdate(new Date());
			order.setPaymentmethod(paymentMethod);
			order.setStatus("pending");
			double totalAmount=0;
			for(CartItem item:cart.getItems().values()) {
				totalAmount+=item.getPrice()*item.getQuantity();
			}
			order.setTotalamount(totalAmount);
			//System.out.print(order.getTotalamount());
			//save the order to the database 
			session.removeAttribute("cart");
			//clear the cart and redirect to the order confirmation page
			session.setAttribute("order", order);
			//System.out.println("checkout");
			resp.sendRedirect("OrderConfirmation.jsp");
		}
		else if(user==null) {
			resp.sendRedirect("login.jsp");
			PrintWriter out=resp.getWriter();
			out.println("you have not loggedin please login in");
		}
		else {
			resp.sendRedirect("cart.jsp");//redirect to cart it's empty or user is not logged in
		}
	}

}
