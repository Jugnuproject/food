package com.food.dao;

import java.util.List;

import com.food.model.OrderItem;
import com.food.model.User;

public interface OrderItemDAO {
	void addOrderItem(OrderItem orderItem);
	OrderItem getOrderItem(int orderItemid);
	void updateOrderItem(OrderItem orderItem);
	void deleteOrderItem(int orderItemid);
	List<OrderItem> getAllOrderItemsByOrder(int orderid);


}
