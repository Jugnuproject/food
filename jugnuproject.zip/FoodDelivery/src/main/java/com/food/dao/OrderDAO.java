package com.food.dao;

import java.util.List;

import com.food.model.Order;
import com.food.model.User;

public interface OrderDAO {
	void addOrder(Order order);
	Order getOrder(int orderid);
	void updateOrder(Order order);
	void deleteOrder(int orderid);
	List<Order> getAllOrdersByUser(int userid);


}
