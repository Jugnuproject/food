package com.food.dao;

import java.util.List;

import com.food.model.User;

public interface UserDAO {
	void addUser(User user);
	User getUser(int userid);
	void updateUser(User user);
	void deleteUser(int userid);
	List<User> getAllUsers();
	User getUserByUsername(String username);

}
