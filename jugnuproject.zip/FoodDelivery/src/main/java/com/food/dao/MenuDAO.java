package com.food.dao;

import java.util.List;

import com.food.model.Menu;
import com.food.model.User;

public interface MenuDAO {
	void addMenu(Menu menu);
	Menu getMenu(int menuid);
	void updateMenu(Menu menu);
	void deleteMenu(int menuid);
	List<Menu> getAllMenusByRestaurant(int restaurantid);


}
