package com.food.dao;

import java.util.List;

import com.food.model.OrderHistory;
import com.food.model.User;

public interface OrderHistoryDAO {
	void addOrderHistory(OrderHistory orderHistory);
	OrderHistory getOrderHistory(int orderHistoryid);
	void updateOrderHistory(OrderHistory orderHistory);
	void deleteOrderHistory(int orderHistoryid);
	List<OrderHistory> getAllOrderHistorysByUser(int userid);


}
