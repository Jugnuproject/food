package com.food.daoimp1;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import com.food.dao.RestaurantDAO;
import com.food.model.Restaurant;

public class RestaurantDAOImp1 implements RestaurantDAO {
	private static Connection connection=null;
	private static PreparedStatement preparestatement=null;
	private static Statement statement=null;
	private static ResultSet res=null;
	
	private final static String INSERT_QUERY="insert into `restaurant` (`restaurantid`,`name`,`cuisinetype`,`deliveryTime`,`address`,`adminuserid`,`rating`,`isactive`,`imagepath`) "
			+ " values (?,?,?,?,?,?,?,?,?)";
	private final static String DELETE_QUERY="delete from `restaurant` where `restaurantid`=?";
	private final static String UPDATE_QUERY="update `restaurant` set `restaurantid`= ?,`name`= ?,`cuisinetype`= ?,`adminuserid`= ?,`rating`=?,`deliveryTime`=?,`address`=?,`isactive`=?,`imagepath`=? where restaurantid= ?";
	private final static String SELECT_QUERY="select * from `restaurant` where `restaurantid`=?";
	private final static String SELECT_ALL_QUERY="select * from `restaurant`";
	public RestaurantDAOImp1() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/fooddeliveryapp","root","root");
			//System.out.println("connection establised successfull");

		}
		catch(ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}

	}

	@Override
	public void addRestaurant(Restaurant restaurant) {
		try {
			preparestatement=connection.prepareStatement(INSERT_QUERY);
			preparestatement.setInt(1, restaurant.getRestaurantid());
			preparestatement.setString(2, restaurant.getName());
			preparestatement.setString(3, restaurant.getCuisinetype());
			preparestatement.setInt(4, restaurant.getDeliveryTime());
			preparestatement.setString(5, restaurant.getAddress());
			preparestatement.setInt(6, restaurant.getAdminuserid());
			preparestatement.setDouble(7, restaurant.getRating());
			preparestatement.setBoolean(8, restaurant.getIsactive());
			preparestatement.setString(9, restaurant.getImagepath());
		    preparestatement.executeUpdate();
		}
		catch(SQLException e1) {
			e1.printStackTrace();
		}
		
	}

	@Override
	public Restaurant getRestaurant(int restaurantid) {
		try {
			preparestatement=connection.prepareStatement(SELECT_QUERY);
			preparestatement.setInt(1, restaurantid);
			res=preparestatement.executeQuery();
			if(res.next()) {
				int restaurantid1=res.getInt("restaurantid");
				String name=res.getString("name");
				String cuisinetype=res.getString("cuisinetype");
				int deliveryTime=res.getInt("deliveryTime");
				String address=res.getString("address");
				int adminuserid=res.getInt("adminuserid");
				Double rating=res.getDouble("rating");
				boolean isactive=res.getBoolean("isactive");
				String imagepath=res.getString("imagepath");
				return new Restaurant(restaurantid,name,cuisinetype,deliveryTime,address,adminuserid,rating,isactive,imagepath);
			}
			
		}
		catch(SQLException e4) {
			e4.printStackTrace();
		}
		return null;
	}

	@Override
	public void updateRestaurant(Restaurant restaurant) {
		try {
			preparestatement=connection.prepareStatement(UPDATE_QUERY);
			preparestatement.setInt(1, restaurant.getRestaurantid());
			preparestatement.setString(2, restaurant.getName());
			preparestatement.setString(3, restaurant.getCuisinetype());
			preparestatement.setInt(4, restaurant.getDeliveryTime());
			preparestatement.setString(5, restaurant.getAddress());
			preparestatement.setInt(6, restaurant.getAdminuserid());
			preparestatement.setDouble(7, restaurant.getRating());
			preparestatement.setBoolean(8, restaurant.getIsactive());
			preparestatement.setString(9, restaurant.getImagepath());
		    preparestatement.executeUpdate();
		}
		catch(SQLException e1) {
			e1.printStackTrace();
		}
		
		
	}

	@Override
	public void deleteRestaurant(int restaurantid) {
		try {
			preparestatement=connection.prepareStatement(DELETE_QUERY);
			preparestatement.setInt(1, restaurantid);
			preparestatement.executeUpdate();
			}
		catch(SQLException e2) {
			e2.printStackTrace();
		}
		
	}

	@Override
	public List<Restaurant> getAllRestaurants() {
		ArrayList<Restaurant> restaurantli =new ArrayList<Restaurant>();
		try {
			statement=connection.createStatement();
			res=statement.executeQuery(SELECT_ALL_QUERY);
			while(res.next()) {
				int restaurantid=res.getInt("restaurantid");
				String name=res.getString("name");
				String cuisinetype=res.getString("cuisinetype");
				int deliveryTime=res.getInt("deliveryTime");
				String address=res.getString("address");
				int adminuserid=res.getInt("adminuserid");
				Double rating=res.getDouble("rating");
				boolean isactive=res.getBoolean("isactive");
				String imagepath=res.getString("imagepath");
				Restaurant res= new Restaurant(restaurantid,name,cuisinetype,deliveryTime,address,adminuserid,rating,isactive,imagepath);
				restaurantli.add(res);
			    }
			}
		
			catch(SQLException e5) {
				e5.printStackTrace();
			}
			return restaurantli;
	}

	
}
	
