package com.food.daoimp1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.food.dao.UserDAO;
import com.food.model.User;


public class UserDAOImp1 implements UserDAO {
	private static Connection connection=null;
	private static PreparedStatement preparestatement=null;
	private static Statement statement=null;
	private static ResultSet res=null;
	
	private final static String INSERT_QUERY="insert into `user` (`userid`,`username`,`password`,`email`,`address`,`role`) "
			+ " values (?,?,?,?,?,?)";
	private final static String DELETE_QUERY="delete from `user` where `userid`=?";
	private final static String UPDATE_QUERY="update `user` set `userid`= ?,`username`= ?,`password`= ?,`email`= ?,`role`=? where userid= ?";
	private final static String SELECT_QUERY="select * from `user` where `userid`=?";
	private final static String SELECT1_QUERY="select * from `user` where `username`=?";
	private final static String SELECT_ALL_QUERY="select * from `user`";
	public UserDAOImp1() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/fooddeliveryapp","root","root");
		}
		catch(ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}

	}
	

	@Override
	public void addUser(User user) {
		try {
			preparestatement=connection.prepareStatement(INSERT_QUERY);
			preparestatement.setInt(1, user.getUserId());
			preparestatement.setString(2, user.getUsername());
			preparestatement.setString(3, user.getPassword());
			preparestatement.setString(4, user.getEmail());
			preparestatement.setString(5, user.getAddress());
			preparestatement.setString(6, user.getRole());
		    preparestatement.executeUpdate();
		}
		catch(SQLException e1) {
			e1.printStackTrace();
		}
		
	}

	@Override
	public User getUser(int userid) {
		try {
			preparestatement=connection.prepareStatement(SELECT_QUERY);
			preparestatement.setInt(1, userid);
			res=preparestatement.executeQuery();
			if(res.next()) {
				int userid1=res.getInt("userid");
				String username=res.getString("username");
				String password=res.getString("password");
				String email=res.getString("email");
				String address=res.getString("address");
				String role=res.getString("role");
				return new User(userid1,username,password,email,address,role);
			}
			
		}
		catch(SQLException e4) {
			e4.printStackTrace();
		}
		return null;
	}

	@Override
	public void updateUser(User user) {
		try {
			preparestatement=connection.prepareStatement(UPDATE_QUERY);
			
			preparestatement.setInt(1, user.getUserId());
			preparestatement.setString(2, user.getUsername());
			preparestatement.setString(3, user.getPassword());
			preparestatement.setString(4, user.getEmail());
			preparestatement.setString(3, user.getAddress());
			preparestatement.setString(4, user.getRole());
			preparestatement.executeUpdate();
			}
		catch(SQLException e3) {
			e3.printStackTrace();
		}
		
	}

	@Override
	public void deleteUser(int userid) {
		try {
			preparestatement=connection.prepareStatement(DELETE_QUERY);
			preparestatement.setInt(1, userid);
			preparestatement.executeUpdate();
			}
		catch(SQLException e2) {
			e2.printStackTrace();
		}
		
	}

	@Override
	public List<User> getAllUsers() {
		ArrayList<User> users=new ArrayList<User>();
		try {
			statement=connection.createStatement();
			res=statement.executeQuery(SELECT_ALL_QUERY);
			while(res.next()) {
				int userid=res.getInt("userid");
				String username=res.getString("username");
				String password=res.getString("password");
				String email=res.getString("email");
				String address=res.getString("address");
				String role=res.getString("role");
				User user=new User(userid,username,password,email,address,role);
				users.add(user);
			}
			
		}
		catch(SQLException e5) {
			e5.printStackTrace();
		}
		return users;
	}
	public User getUserByUsername(String username) {
		try {
			preparestatement=connection.prepareStatement(SELECT1_QUERY);
			preparestatement.setString(1, username);
			res=preparestatement.executeQuery();
			if(res.next()) {
				int userid=res.getInt("userid");
				String username1=res.getString("username");
				String password=res.getString("password");
				String email=res.getString("email");
				String address=res.getString("address");
				String role=res.getString("role");
				return new User(userid,username1,password,email,address,role);
			}
			
		}
		catch(SQLException e4) {
			e4.printStackTrace();
		}
		return null;
	}
	

}
