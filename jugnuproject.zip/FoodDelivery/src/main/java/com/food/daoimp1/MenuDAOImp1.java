package com.food.daoimp1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.food.dao.MenuDAO;
import com.food.model.Menu;

public class MenuDAOImp1 implements MenuDAO {
	private static Connection connection=null;
	private static PreparedStatement preparestatement=null;
	private static Statement statement=null;
	private static ResultSet res=null;
	
	private final static String INSERT_QUERY="insert into `menu` (`menuid`,`restaurantid`,`itemname`,`description`,`price`,`isavailable`)"
			+ " values (?,?,?,?,?,?)";
	private final static String DELETE_QUERY="delete from `menu` where `menuid`=?";
	private final static String UPDATE_QUERY="update `menu` set `menuid`= ?,`restaurantid`= ?,`itemname`= ?,`description`= ?,`price`=?,`isavailable`=? where `menuid`= ?";
	private final static String SELECT_QUERY="select * from `menu` where `menuid`=?";
	private final static String SELECT_ALL_QUERY="select * from `menu` where `restaurantid`=?";
	public MenuDAOImp1() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/fooddeliveryapp","root","root");
		}
		catch(ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}

	}

	@Override
	public void addMenu(Menu menu) {
		try {
			preparestatement=connection.prepareStatement(INSERT_QUERY);
			preparestatement.setInt(1, menu.getMenuid());
			preparestatement.setInt(2, menu.getRestaurantid());
			preparestatement.setString(3, menu.getItemname());
			preparestatement.setString(4, menu.getDescription());
			preparestatement.setDouble(5, menu.getPrice());
			preparestatement.setBoolean(6, menu.getIsavailable());
		    preparestatement.executeUpdate();
		}
		catch(SQLException e1) {
			e1.printStackTrace();
		}
		
		
	}

	@Override
	public Menu getMenu(int menuid) {
		try {
			preparestatement=connection.prepareStatement(SELECT_QUERY);
			preparestatement.setInt(1, menuid);
			res=preparestatement.executeQuery();
			if(res.next()) {
				int menuid1=res.getInt("menuid");
				int restaurantid=res.getInt("restaurantid");
				String itemname=res.getString("itemname");
				String description=res.getString("description");
				double price=res.getDouble("price");
				boolean isavailable=res.getBoolean("isavailable");
				return new Menu(menuid1,restaurantid,itemname,description,price,isavailable);
			}
			
		}
		catch(SQLException e4) {
			e4.printStackTrace();
		}
		return null;
	}

	@Override
	public void updateMenu(Menu menu) {
		try {
			preparestatement=connection.prepareStatement(UPDATE_QUERY);
			preparestatement.setInt(1, menu.getMenuid());
			preparestatement.setInt(2, menu.getRestaurantid());
			preparestatement.setString(3, menu.getItemname());
			preparestatement.setString(4, menu.getDescription());
			preparestatement.setDouble(5, menu.getPrice());
			preparestatement.setBoolean(6, menu.getIsavailable());
		    preparestatement.executeUpdate();
		}
		catch(SQLException e1) {
			e1.printStackTrace();
		}
		
		
	}

	@Override
	public void deleteMenu(int menuid) {
		try {
			preparestatement=connection.prepareStatement(DELETE_QUERY);
			preparestatement.setInt(1, menuid);
			preparestatement.executeUpdate();
			}
		catch(SQLException e2) {
			e2.printStackTrace();
		}
		
		
	}

	@Override
	public List<Menu> getAllMenusByRestaurant(int restaurantid) {
		ArrayList<Menu> menus =new ArrayList<Menu>();
		try {
			preparestatement=connection.prepareStatement(SELECT_ALL_QUERY);
			preparestatement.setInt(1, restaurantid);
			res=preparestatement.executeQuery();
			while(res.next()) {
				int menuid1=res.getInt("menuid");
				int restaurantid1=res.getInt("restaurantid");
				String itemname=res.getString("itemname");
				String description=res.getString("description");
				double price=res.getDouble("price");
				boolean isavailable=res.getBoolean("isavailable");
				Menu menu= new Menu(menuid1,restaurantid1,itemname,description,price,isavailable);
				menus.add(menu);
			}
			
		}
		catch(SQLException e4) {
			e4.printStackTrace();
		}
		return menus;
	}
	

}
