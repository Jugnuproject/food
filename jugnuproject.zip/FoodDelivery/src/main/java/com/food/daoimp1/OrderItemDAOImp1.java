package com.food.daoimp1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.food.dao.OrderItemDAO;
import com.food.model.Order;
import com.food.model.OrderItem;

public class OrderItemDAOImp1 implements OrderItemDAO {
	private static Connection connection=null;
	private static PreparedStatement preparestatement=null;
	private static Statement statement=null;
	private static ResultSet res=null;
	
	private final static String INSERT_QUERY="insert into `order` (`orderitemid`,`orderid`,`menuid`,`quality`,`itemtotal`) "
			+ " values (?,?,?,?,?)";
	private final static String DELETE_QUERY="delete from `orderitem` where `orderitemid`=?";
	private final static String UPDATE_QUERY="update `orderitem` set `orderitemid`= ?,`orderid`=?,`menuid`= ?,`quality`= ?,`itemtotal`= ?, where orderitemid= ?";
	private final static String SELECT_QUERY="select * from `orderitem` where `orderitemid`=?";
	private final static String SELECT_ALL_QUERY="select * from `orderitem`";
	public OrderItemDAOImp1() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/fooddeliveryapp","root","root");
		}
		catch(ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}

	}

	@Override
	public void addOrderItem(OrderItem orderItem) {
		try {
			preparestatement=connection.prepareStatement(INSERT_QUERY);
			preparestatement.setInt(1, orderItem.getOrderitemid());
			preparestatement.setInt(2, orderItem.getOrderid());
			preparestatement.setInt(3, orderItem.getMenuid());
			preparestatement.setInt(4, orderItem.getQuality());
			preparestatement.setInt(5, orderItem.getItemtotal());
		    preparestatement.executeUpdate();
		}
		catch(SQLException e1) {
			e1.printStackTrace();
		}
		
	}

	@Override
	public OrderItem getOrderItem(int orderItemid) {
		try {
			preparestatement=connection.prepareStatement(SELECT_QUERY);
			preparestatement.setInt(1, orderItemid);
			res=preparestatement.executeQuery();
			if(res.next()) {
				int orderItemid1=res.getInt("orderItemid");
				int orderid=res.getInt("orderid");
				int menuid=res.getInt("menuid");
				int quality=res.getInt("quality");
				int itemtotal=res.getInt("itemtotal");
				return new OrderItem(orderItemid1,orderid,menuid,quality,itemtotal);
			}
			
		}
		catch(SQLException e4) {
			e4.printStackTrace();
		}
		return null;
	}

	@Override
	public void updateOrderItem(OrderItem orderItem) {
		try {
			preparestatement=connection.prepareStatement(UPDATE_QUERY);
			preparestatement.setInt(1, orderItem.getOrderitemid());
			preparestatement.setInt(2, orderItem.getOrderid());
			preparestatement.setInt(3, orderItem.getMenuid());
			preparestatement.setInt(4, orderItem.getQuality());
			preparestatement.setInt(5, orderItem.getItemtotal());
		    preparestatement.executeUpdate();
		}
		catch(SQLException e1) {
			e1.printStackTrace();
		}
		
	}

	@Override
	public void deleteOrderItem(int orderItemid) {
		try {
			preparestatement=connection.prepareStatement(DELETE_QUERY);
			preparestatement.setInt(1, orderItemid);
			preparestatement.executeUpdate();
			}
		catch(SQLException e2) {
			e2.printStackTrace();
		}
		
		
	}

	@Override
	public List<OrderItem> getAllOrderItemsByOrder(int orderid) {
		ArrayList<OrderItem> orderItems=new ArrayList<OrderItem>();
		try {
			statement=connection.createStatement();
			res=statement.executeQuery(SELECT_ALL_QUERY);
			while(res.next()) {
				int orderItemid=res.getInt("orderItemid");
				int orderid1=res.getInt("orderid");
				int menuid=res.getInt("menuid");
				int quality=res.getInt("quality");
				int itemtotal=res.getInt("itemtotal");
				OrderItem orderItem=new OrderItem(orderItemid,orderid1,menuid,quality,itemtotal);
				orderItems.add(orderItem);
			}
			
		}
		catch(SQLException e4) {
			e4.printStackTrace();
		}
		return orderItems;
	}
	

}
