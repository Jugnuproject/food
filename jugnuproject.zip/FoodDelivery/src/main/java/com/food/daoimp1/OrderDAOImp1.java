package com.food.daoimp1;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.food.dao.OrderDAO;
import com.food.model.Menu;
import com.food.model.Order;
import com.food.model.User;

public class OrderDAOImp1 implements OrderDAO {
	private static Connection connection=null;
	private static PreparedStatement preparestatement=null;
	private static Statement statement=null;
	private static ResultSet res=null;
	
	private final static String INSERT_QUERY="insert into `order` (`orderid`,`userid`,`restaurantid`,`orderdate`,`totalamount`,`status`,`paymentmethod`) "
			+ " values (?,?,?,?,?,?,?)";
	private final static String DELETE_QUERY="delete from `order` where `orderid`=?";
	private final static String UPDATE_QUERY="update `order` set `orderid`= ?,`userid`=?,`restaurantid`= ?,`orderdate`= ?,`totalamount`= ?,`status`=?,`paymentmethod`=? where orderid= ?";
	private final static String SELECT_QUERY="select * from `order` where `orderid`=?";
	private final static String SELECT_ALL_QUERY="select * from `order`";
	public OrderDAOImp1() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/fooddeliveryapp","root","root");
		}
		catch(ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}

	}
	@Override
	public void addOrder(Order order) {
		try {
			preparestatement=connection.prepareStatement(INSERT_QUERY);
			preparestatement.setInt(1, order.getOrderid());
			preparestatement.setInt(2, order.getUserid());
			preparestatement.setInt(3, order.getRestaurantid());
			preparestatement.setDate(4, (Date)order.getOrderdate());
			preparestatement.setDouble(5, order.getTotalamount());
			preparestatement.setString(6, order.getStatus());
			preparestatement.setString(7, order.getPaymentmethod());
		    preparestatement.executeUpdate();
		}
		catch(SQLException e1) {
			e1.printStackTrace();
		}
		
		
	}
	@Override
	public Order getOrder(int orderid) {
		try {
			preparestatement=connection.prepareStatement(SELECT_QUERY);
			preparestatement.setInt(1, orderid);
			res=preparestatement.executeQuery();
			if(res.next()) {
				int orderid1=res.getInt("orderid");
				int userid=res.getInt("userid");
				int restaurantid=res.getInt("restaurantid");
				Date orderdate=res.getDate("orderdate");
				Double totalamount=res.getDouble("totalamount");
				String status=res.getString("status");
				String paymentmethod=res.getString("paymentmethod");
				return new Order(orderid,userid,restaurantid,orderdate,totalamount,status,paymentmethod);
			}
			
		}
		catch(SQLException e4) {
			e4.printStackTrace();
		}
		
		return null;
	}
	@Override
	public void updateOrder(Order order) {
		try {
			preparestatement=connection.prepareStatement(UPDATE_QUERY);
			preparestatement.setInt(1, order.getOrderid());
			preparestatement.setInt(2, order.getUserid());
			preparestatement.setInt(3, order.getRestaurantid());
			preparestatement.setDate(4, (Date) order.getOrderdate());
			preparestatement.setDouble(5, order.getTotalamount());
			preparestatement.setString(6, order.getStatus());
			preparestatement.setString(7, order.getPaymentmethod());
		    preparestatement.executeUpdate();
		}
		catch(SQLException e1) {
			e1.printStackTrace();
		}
		
	}
	@Override
	public void deleteOrder(int orderid) {
		try {
			preparestatement=connection.prepareStatement(DELETE_QUERY);
			preparestatement.setInt(1, orderid);
			preparestatement.executeUpdate();
			}
		catch(SQLException e2) {
			e2.printStackTrace();
		}
		
		
	}
	@Override
	public List<Order> getAllOrdersByUser(int userid) {
		ArrayList<Order> orders=new ArrayList<Order>();
		try {
			statement=connection.createStatement();
			res=statement.executeQuery(SELECT_ALL_QUERY);
			while(res.next()) {
				int orderid=res.getInt("orderid");
				int userid1=res.getInt("userid");
				int restaurantid=res.getInt("restaurantid");
				Date orderdate=res.getDate("orderdate");
				Double totalamount=res.getDouble("totalamount");
				String status=res.getString("status");
				String paymentmethod=res.getString("paymentmethod");
				Order order= new Order(orderid,userid1,restaurantid,orderdate,totalamount,status,paymentmethod);
				orders.add(order);
			}
		}
		catch(SQLException e4) {
			e4.printStackTrace();
		}
		return orders;
	}
	
	

}
