package com.food.daoimp1;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.food.dao.OrderHistoryDAO;
import com.food.model.OrderHistory;
import com.food.model.OrderItem;

public class OrderHistoryDAOImp1 implements OrderHistoryDAO {
	private static Connection connection=null;
	private static PreparedStatement preparestatement=null;
	private static Statement statement=null;
	private static ResultSet res=null;
	
	private final static String INSERT_QUERY="insert into `order` (`orderhistoryid`,`userid`,`orderid`,`orderdate,`totalamount`,`status`) "
			+ " values (?,?,?,?,?,?)";
	private final static String DELETE_QUERY="delete from `orderhistory` where `orderhistoryid`=?";
	private final static String UPDATE_QUERY="update `orderhistory` set `orderhistoryid`= ?,,`userid`=?,`orderid`=?,`orderdate`= ?,`totalamount`= ?,`status`=? where orderhistoryid= ?";
	private final static String SELECT_QUERY="select * from `orderhistory` where `orderhistoryid`=?";
	private final static String SELECT_ALL_QUERY="select * from `orderhistory`";
	public OrderHistoryDAOImp1() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/fooddeliveryapp","root","root");
		}
		catch(ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}

	}
	@Override
	public void addOrderHistory(OrderHistory orderHistory) {
		try {
			preparestatement=connection.prepareStatement(INSERT_QUERY);
			preparestatement.setInt(1, orderHistory.getOrderhistoryid());
			preparestatement.setInt(2,orderHistory.getUserid());
			preparestatement.setInt(3, orderHistory.getOrderid());
			preparestatement.setDate(4,(Date)orderHistory.getOrderdate());
			preparestatement.setDouble(5, orderHistory.getTotalamount());
			preparestatement.setString(6, orderHistory.getStatus());
		    preparestatement.executeUpdate();
		}
		catch(SQLException e1) {
			e1.printStackTrace();
		}
		
	}
	@Override
	public OrderHistory getOrderHistory(int orderHistoryid) {
		try {
			preparestatement=connection.prepareStatement(SELECT_QUERY);
			preparestatement.setInt(1, orderHistoryid);
			res=preparestatement.executeQuery();
			if(res.next()) {
				int orderHistoryid1=res.getInt("orderItemid");
				int userid=res.getInt("userid");
				int orderid=res.getInt("orderid");
				Date orderdate=res.getDate("orderdate");
				double totalamount=res.getDouble("totalamount");
				String status=res.getString("status");
				return new OrderHistory(orderHistoryid1,userid,orderid,orderdate,totalamount,status);
			}
			
		}
		catch(SQLException e4) {
			e4.printStackTrace();
		}
		return null;
	}
	@Override
	public void updateOrderHistory(OrderHistory orderHistory) {
		try {
			preparestatement=connection.prepareStatement(UPDATE_QUERY);
			preparestatement.setInt(1, orderHistory.getOrderhistoryid());
			preparestatement.setInt(2,orderHistory.getUserid());
			preparestatement.setInt(3, orderHistory.getOrderid());
			preparestatement.setDate(4,(Date)orderHistory.getOrderdate());
			preparestatement.setDouble(5, orderHistory.getTotalamount());
			preparestatement.setString(6, orderHistory.getStatus());
		    preparestatement.executeUpdate();
		}
		catch(SQLException e1) {
			e1.printStackTrace();
		}
		
	}
	@Override
	public void deleteOrderHistory(int orderHistoryid) {
		try {
			preparestatement=connection.prepareStatement(DELETE_QUERY);
			preparestatement.setInt(1, orderHistoryid);
			preparestatement.executeUpdate();
			}
		catch(SQLException e2) {
			e2.printStackTrace();
		}
		
	}
	@Override
	public List<OrderHistory> getAllOrderHistorysByUser(int userid) {
		ArrayList<OrderHistory> orderHistoryItems=new ArrayList<OrderHistory>();
		try {
			statement=connection.createStatement();
			res=statement.executeQuery(SELECT_ALL_QUERY);
			while(res.next()) {
				int orderHistoryid=res.getInt("orderItemid");
				int userid1=res.getInt("userid");
				int orderid=res.getInt("orderid");
				Date orderdate=res.getDate("orderdate");
				double totalamount=res.getDouble("totalamount");
				String status=res.getString("status");
				OrderHistory orderHistory= new OrderHistory(orderHistoryid,userid1,orderid,orderdate,totalamount,status);
				orderHistoryItems.add(orderHistory);
			}
		}
		catch(SQLException e4) {
			e4.printStackTrace();
		}
		return orderHistoryItems;
	}

	

}
