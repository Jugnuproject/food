package com.food.model;

public class OrderItem {
	private int orderitemid;
	private int orderid;
	private int menuid;
	private int quality;
	private int itemtotal;
	public OrderItem(int orderitemid, int orderid, int menuid, int quality, int itemtotal) {
		super();
		this.orderitemid = orderitemid;
		this.orderid = orderid;
		this.menuid = menuid;
		this.quality = quality;
		this.itemtotal = itemtotal;
	}
	public int getOrderitemid() {
		return orderitemid;
	}
	public void setOrderitemid(int orderitemid) {
		this.orderitemid = orderitemid;
	}
	public int getOrderid() {
		return orderid;
	}
	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}
	public int getMenuid() {
		return menuid;
	}
	public void setMenuid(int menuid) {
		this.menuid = menuid;
	}
	public int getQuality() {
		return quality;
	}
	public void setQuality(int quality) {
		this.quality = quality;
	}
	public int getItemtotal() {
		return itemtotal;
	}
	public void setItemtotal(int itemtotal) {
		this.itemtotal = itemtotal;
	}
	@Override
	public String toString() {
		return "OrderItem [orderitemid=" + orderitemid + ", orderid=" + orderid + ", menuid=" + menuid + ", quality="
				+ quality + ", itemtotal=" + itemtotal + "]";
	}
	
	
	

}
