package com.food.model;

import java.sql.Blob;

public class Restaurant {
	private int restaurantid;
	private String name;
	private String cuisinetype;
	private int deliveryTime;
	private String address;
	private int adminuserid;
	private double rating;
	private boolean isactive;
	private String imagepath;
	public Restaurant(int restaurantid, String name, String cuisinetype, int deliveryTime, String address,
			int adminuserid, double rating, boolean isactive, String imagepath) {
		super();
		this.restaurantid = restaurantid;
		this.name = name;
		this.cuisinetype = cuisinetype;
		this.deliveryTime = deliveryTime;
		this.address = address;
		this.adminuserid = adminuserid;
		this.rating = rating;
		this.isactive = isactive;
		this.imagepath = imagepath;
	}
	public int getRestaurantid() {
		return restaurantid;
	}
	public void setRestaurantid(int restaurantid) {
		this.restaurantid = restaurantid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCuisinetype() {
		return cuisinetype;
	}
	public void setCuisinetype(String cuisinetype) {
		this.cuisinetype = cuisinetype;
	}
	public int getDeliveryTime() {
		return deliveryTime;
	}
	public void setDeliveryTime(int deliveryTime) {
		this.deliveryTime = deliveryTime;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getAdminuserid() {
		return adminuserid;
	}
	public void setAdminuserid(int adminuserid) {
		this.adminuserid = adminuserid;
	}
	public double getRating() {
		return rating;
	}
	public void setRating(double rating) {
		this.rating = rating;
	}
	public boolean getIsactive() {
		return isactive;
	}
	public void setIsactive(boolean isactive) {
		this.isactive = isactive;
	}
	public String getImagepath() {
		return imagepath;
	}
	public void setImagepath(String imagepath) {
		this.imagepath = imagepath;
	}
	@Override
	public String toString() {
		return "Restaurant [restaurantid=" + restaurantid + ", name=" + name + ", cuisinetype=" + cuisinetype
				+ ", deliveryTime=" + deliveryTime + ", address=" + address + ", adminuserid=" + adminuserid
				+ ", rating=" + rating + ", isactive=" + isactive + ", imagepath=" + imagepath + "]";
	}
	
	
	


}
