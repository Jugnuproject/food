package com.food.model;

import java.util.HashMap;
import java.util.Map;

public class Cart {
	//the cart items is stored as a map of item IDs to caritem objects 
	private Map<Integer,CartItem> items;
	public Cart() {
		this.items=new HashMap<>();
		
	}
	//add an item to the cart
	public void addItem(CartItem item) {
		int itemId=item.getItemid();
		if(items.containsKey(itemId)) {
			//IF ITEM ALREADY EXISTS,INCREASE THE QUANTITY
			CartItem existingItem=items.get(itemId);
			existingItem.setQuantity(existingItem.getQuantity()+item.getQuantity());
			
		}else {
			//if item is new ,add to cart
			items.put(itemId, item);
		}
		
		
	}
	//update the quantity of an item in the cart
	public void updateItem(int itemId,int quantity) {
		if(items.containsKey(itemId)) {
			if(quantity<=0) {
				items.remove(itemId);
				
			}
			else {
				items.get(itemId).setQuantity(quantity);
			}
		}
	}
	//remove an item from the cart
	public void removeItem(int itemId) {
		items.remove(itemId);
		
	}
	//get all items in the cart
	public Map<Integer,CartItem> getItems(){
		return items;
	}
	//clear the cart
	public void clear() {
		items.clear();
		
	}

}
